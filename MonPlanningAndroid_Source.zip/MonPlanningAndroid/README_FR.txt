MON PLANNING — PROJET ANDROID

Le fichier index.html est votre application d'origine intégrée dans une petite application Android WebView.
Les données du planning sont enregistrées localement par le navigateur intégré (localStorage).

IMPORTANT : ce dossier est le PROJET SOURCE, pas un APK déjà compilé. Pour obtenir l'APK :
1. Ouvrir ce dossier dans Android Studio sur un ordinateur.
2. Laisser Android Studio synchroniser Gradle et installer les composants Android demandés.
3. Aller dans Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Récupérer l'APK dans app/build/outputs/apk/debug/app-debug.apk et le transférer sur le téléphone.
5. Sur Android, ouvrir le fichier APK et autoriser temporairement l'installation depuis cette source si demandé.

Limite connue de la version actuelle : les rappels/minuteurs fonctionnent quand l'application est ouverte; le HTML lui-même indique déjà que les alarmes ne sont pas garanties lorsque le téléphone est verrouillé. Aucun service réseau n'est requis pour l'interface.
